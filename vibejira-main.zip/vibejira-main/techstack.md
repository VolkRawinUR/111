Frontend:
- React
- CoreUI

Backend:
- Express.js
- JIRA REST API
- NodeJS

Database:
None (Direct JIRA API usage)